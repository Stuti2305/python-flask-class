name='Stuti'
age=19
city="lucknow"
designation='student'
course='BCA'
print("My name is {}".format(name))
print("my age is {}".format(age))
print("I'm from {}".format(city))
print("I'm a {} and currently i'm pursuing {}".format(designation,course))